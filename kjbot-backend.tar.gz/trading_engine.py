"""
KJBot Trading Engine
바이낸스/업비트 거래 실행 엔진
"""

import ccxt
import logging
import threading
from typing import Dict, Any, List, Optional
from config_manager import config_manager
from discord_notifier import discord_notifier

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

MAX_FLIP_LIMIT_SLOTS = 4


class TradingEngine:
    """거래 실행 엔진"""
    
    def __init__(self):
        self.exchanges: Dict[str, ccxt.Exchange] = {}
        self.config = config_manager.load_config()
        self._flip_ladders: Dict[str, Dict[str, Any]] = {}
        self._stop_sync_timers: Dict[str, List[threading.Timer]] = {}
        self._symbol_locks: Dict[str, threading.Lock] = {}
        self._locks_guard = threading.Lock()
        self._trend_cycles: Dict[str, Dict[str, Any]] = {}
        self._trend_sync_timers: Dict[str, List[threading.Timer]] = {}
        self.initialize_exchanges()
        self.initialize_notifications()
    
    def initialize_exchanges(self):
        """거래소 초기화"""
        # Binance 초기화
        binance_keys = config_manager.get_api_keys("binance")
        if binance_keys:
            try:
                self.exchanges["binance"] = ccxt.binance({
                    'apiKey': binance_keys['api_key'],
                    'secret': binance_keys['secret_key'],
                    'enableRateLimit': True,
                    'options': {
                        'defaultType': 'future',  # 선물 거래
                    }
                })
                logger.info("✅ Binance 연결 성공")
            except Exception as e:
                logger.error(f"❌ Binance 초기화 실패: {e}")
        
        # Upbit 초기화
        upbit_keys = config_manager.get_api_keys("upbit")
        if upbit_keys:
            try:
                self.exchanges["upbit"] = ccxt.upbit({
                    'apiKey': upbit_keys['api_key'],
                    'secret': upbit_keys['secret_key'],
                    'enableRateLimit': True,
                })
                logger.info("✅ Upbit 연결 성공")
            except Exception as e:
                logger.error(f"❌ Upbit 초기화 실패: {e}")
    
    def initialize_notifications(self):
        """디스코드 알림 초기화"""
        notifications_config = self.config.get("notifications", {})
        webhook_url = notifications_config.get("discord_webhook_url", "")
        
        if webhook_url:
            discord_notifier.set_webhook_url(webhook_url)
            logger.info("✅ 디스코드 알림 활성화")
        else:
            logger.info("ℹ️ 디스코드 알림 비활성화 (웹훅 URL 미설정)")
    
    
    def execute_signal(self, signal: Dict[str, Any]) -> Dict[str, Any]:
        """
        TradingView 시그널 실행
        
        Args:
            signal: {
                "action": "long_entry" | "short_entry" | "long_exit" | "short_exit",
                "symbol": "BTCUSDT",
                "exchange": "binance" | "upbit",
                "leverage": 10,
                "amount": 100,  # USDT
                "percent": 50   # 포지션의 50% 청산
            }
        
        Returns:
            실행 결과
        """
        try:
            action = signal.get("action")
            symbol = signal.get("symbol", "BTCUSDT")
            exchange_name = signal.get("exchange", "binance").lower()
            
            # 심볼 정규화 (바이낸스 선물 형식으로 변환)
            # TradingView에서 "GASUSDT.P" 형식으로 올 수 있으므로 ".P" 제거
            if exchange_name == "binance":
                symbol = symbol.replace(".P", "").upper()
            
            logger.info(f"📊 처리할 심볼: {symbol} (원본: {signal.get('symbol', 'N/A')})")
            
            # 거래 활성화 확인
            if not self.config["trading"]["enable_trading"]:
                return {
                    "success": False,
                    "message": "⚠️ 거래가 비활성화되어 있습니다",
                    "signal": signal
                }
            
            # 거래소 확인
            if exchange_name not in self.exchanges:
                return {
                    "success": False,
                    "message": f"❌ {exchange_name} 거래소가 연결되지 않았습니다",
                    "signal": signal
                }
            
            exchange = self.exchanges[exchange_name]
            
            # [복리 모드] 퍼센트(%) 기반 진입 금액 계산 (size_base: equity | balance)
            needs_sizing = "amount" not in signal and (
                ("percent" in signal and "entry" in action)
                or action in ("short_limit", "long_limit")
            )
            if needs_sizing:
                try:
                    size_base = str(signal.get("size_base", "balance")).lower()
                    sizing_usdt = self._get_sizing_usdt(exchange, size_base)
                    if action in ("short_limit", "long_limit"):
                        flip_pct = float(signal.get("flip_equity_pct", 0))
                        share_pct = float(signal.get("share_pct", 0))
                        calculated_amount = sizing_usdt * (flip_pct / 100.0) * (share_pct / 100.0)
                        logger.info(
                            f"💰 리밋 분배({size_base}): {sizing_usdt:.2f} × flip {flip_pct}% × share {share_pct}% = {calculated_amount:.2f} USDT"
                        )
                    else:
                        calculated_amount = sizing_usdt * (float(signal["percent"]) / 100.0)
                        logger.info(
                            f"💰 복리 계산({size_base}): {sizing_usdt:.2f} USDT 중 {signal['percent']}% = {calculated_amount:.2f} USDT"
                        )
                    if calculated_amount < 10:
                        logger.warning(f"⚠️ 계산된 금액({calculated_amount:.2f})이 너무 작아 최소금액 11 USDT로 조정합니다.")
                        calculated_amount = 11
                    signal["amount"] = round(calculated_amount, 2)
                except Exception as e:
                    logger.error(f"❌ 금액 계산 실패: {e}")
                    signal["amount"] = 100
            
            # 액션별 처리
            result = None
            if action == "long_entry":
                result = self._execute_long_entry(exchange, symbol, signal)
            elif action == "short_entry":
                result = self._execute_short_entry(exchange, symbol, signal)
            elif action == "long_exit":
                if exchange_name == "binance":
                    self._cancel_flip_ladder_orders(exchange, symbol)
                    self._cancel_trend_cycle_orders(exchange, symbol)
                result = self._execute_long_exit(exchange, symbol, signal)
            elif action == "short_exit":
                if exchange_name == "binance":
                    self._cancel_flip_ladder_orders(exchange, symbol)
                    self._cancel_trend_cycle_orders(exchange, symbol)
                result = self._execute_short_exit(exchange, symbol, signal)
            elif action == "long_limit":
                result = self._execute_limit_entry(exchange, symbol, signal, is_short=False)
            elif action == "short_limit":
                result = self._execute_limit_entry(exchange, symbol, signal, is_short=True)
            elif action == "long_limit_ladder":
                result = self._execute_limit_ladder(exchange, symbol, signal, is_short=False)
            elif action == "short_limit_ladder":
                result = self._execute_limit_ladder(exchange, symbol, signal, is_short=True)
            elif action == "trend_flip_start":
                result = self._execute_trend_flip_start(exchange, symbol, signal)
            elif action == "trend_market_entry":
                is_short = bool(signal.get("is_short", False))
                result = self._execute_trend_market_entry(exchange, symbol, signal, is_short=is_short)
            else:
                result = {
                    "success": False,
                    "message": f"❌ 알 수 없는 액션: {action}",
                    "signal": signal
                }
            
            # 디스코드 알림 전송 (실제 거래가 발생한 경우만)
            skip_notification = result.get("skip_notification", False)
            if self.config.get("notifications", {}).get("enable_notifications", False) and not skip_notification:
                try:
                    discord_notifier.send_trade_notification(result)
                except Exception as e:
                    logger.warning(f"⚠️ 디스코드 알림 전송 실패: {e}")
            
            return result
        
        except Exception as e:
            logger.error(f"❌ 시그널 실행 실패: {e}")
            return {
                "success": False,
                "message": f"❌ 실행 오류: {str(e)}",
                "signal": signal
            }
    
    def _get_sizing_usdt(self, exchange: ccxt.Exchange, size_base: str = "balance") -> float:
        """포지션 크기 계산 기준 USDT. equity=총자산(total), balance=가용(free)."""
        balance = exchange.fetch_balance()
        usdt = balance.get("USDT", {})
        if size_base == "equity":
            total = float(usdt.get("total") or 0)
            if total > 0:
                return total
        free_val = balance.get("free", {})
        if isinstance(free_val, dict) and "USDT" in free_val:
            return float(free_val["USDT"])
        return float(usdt.get("free") or usdt.get("total") or 0)

    def _get_symbol_lock(self, normalized_symbol: str) -> threading.Lock:
        with self._locks_guard:
            if normalized_symbol not in self._symbol_locks:
                self._symbol_locks[normalized_symbol] = threading.Lock()
            return self._symbol_locks[normalized_symbol]

    def _calc_limit_amount_usdt(
        self, exchange: ccxt.Exchange, signal: Dict[str, Any], share_pct: float
    ) -> float:
        size_base = str(signal.get("size_base", "balance")).lower()
        sizing_usdt = self._get_sizing_usdt(exchange, size_base)
        flip_pct = float(signal.get("flip_equity_pct", 0))
        calculated_amount = sizing_usdt * (flip_pct / 100.0) * (share_pct / 100.0)
        if calculated_amount < 10:
            calculated_amount = 11
        return round(calculated_amount, 2)

    def _normalize_symbol(self, exchange: ccxt.Exchange, symbol: str) -> str:
        """심볼 정규화 (거래소 형식에 맞게 변환)"""
        try:
            original_symbol = symbol
            # 바이낸스 선물: "GASUSDT.P" -> "GASUSDT"
            symbol = symbol.replace(".P", "").upper()
            
            if isinstance(exchange, ccxt.binance):
                # ccxt 마켓 정보 로드
                markets = exchange.load_markets()
                
                # 직접 매칭 시도
                if symbol in markets:
                    market_id = markets[symbol]['id']
                    logger.debug(f"✅ 심볼 매칭: {original_symbol} -> {symbol} -> {market_id}")
                    return market_id
                
                # ccxt 통합 형식으로 시도 (예: "GAS/USDT:USDT")
                unified_symbol = symbol
                if len(symbol) > 4 and symbol.endswith("USDT"):
                    base = symbol[:-4]
                    unified_symbol = f"{base}/USDT:USDT"
                    if unified_symbol in markets:
                        market_id = markets[unified_symbol]['id']
                        logger.debug(f"✅ 통합 형식 매칭: {original_symbol} -> {unified_symbol} -> {market_id}")
                        return market_id
                
                # 매칭 실패 시 원본 심볼 반환 (ccxt가 자동 처리)
                logger.warning(f"⚠️ 심볼 매칭 실패, 원본 사용: {original_symbol} -> {symbol}")
                return symbol
            
            return symbol
        except Exception as e:
            logger.warning(f"⚠️ 심볼 정규화 실패, 원본 사용: {symbol} ({e})")
            return symbol.replace(".P", "").upper()
    
    def _get_position(self, exchange: ccxt.Exchange, symbol: str, side: str) -> Optional[Dict]:
        """포지션 조회 헬퍼 함수"""
        try:
            # 심볼 정규화
            normalized_symbol = self._normalize_symbol(exchange, symbol)
            positions = exchange.fetch_positions([normalized_symbol])
            position = next((p for p in positions if p['side'] == side), None)
            if position and position['contracts'] > 0:
                return position
            return None
        except Exception as e:
            logger.error(f"❌ 포지션 조회 실패: {symbol} -> {normalized_symbol if 'normalized_symbol' in locals() else 'N/A'} ({e})")
            return None
    
    def _execute_long_entry(self, exchange: ccxt.Exchange, symbol: str, signal: Dict) -> Dict:
        """롱 진입"""
        try:
            # 기존 포지션 확인
            long_position = self._get_position(exchange, symbol, 'long')
            short_position = self._get_position(exchange, symbol, 'short')
            
            # 같은 방향 포지션이 있으면 차단
            if long_position:
                return {
                    "success": False,
                    "message": "⚠️ 이미 롱 포지션이 있습니다. 분할 청산(long_exit)을 사용하세요.",
                    "signal": signal
                }
            
            # 반대 포지션이 있으면 먼저 100% 청산
            if short_position:
                logger.info(f"🔄 숏 포지션 감지 → 100% 청산 후 롱 진입")
                close_result = self._execute_short_exit(exchange, symbol, {"percent": 100})
                if not close_result["success"]:
                    return {
                        "success": False,
                        "message": f"❌ 기존 숏 포지션 청산 실패: {close_result['message']}",
                        "signal": signal
                    }
                logger.info(f"✅ 숏 포지션 청산 완료 → 롱 진입 진행")
            
            leverage = signal.get("leverage", self.config["trading"]["default_leverage"])
            amount_usdt = signal.get("amount", 100)
            
            # 심볼 정규화
            normalized_symbol = self._normalize_symbol(exchange, symbol)
            logger.info(f"🔧 심볼 정규화: {symbol} -> {normalized_symbol}")
            
            # 레버리지 및 마진 모드 설정 (Binance Futures)
            if isinstance(exchange, ccxt.binance):
                try:
                    # 레버리지 설정
                    exchange.set_leverage(leverage, normalized_symbol)
                    logger.info(f"⚙️ 레버리지 설정: {leverage}x ({normalized_symbol})")
                    
                    # 마진 모드 설정 (isolated/cross)
                    margin_mode = self.config["trading"].get("margin_mode", "isolated")
                    exchange.set_margin_mode(margin_mode, normalized_symbol)
                    logger.info(f"⚙️ 마진 모드 설정: {margin_mode} ({normalized_symbol})")
                except Exception as e:
                    logger.warning(f"⚠️ 레버리지/마진 모드 설정 실패 (계속 진행): {e}")
            
            # 현재 가격 조회
            ticker = exchange.fetch_ticker(normalized_symbol)
            current_price = ticker['last']
            logger.info(f"💰 현재 가격: {normalized_symbol} = {current_price}")
            
            # 수량 계산
            quantity = (amount_usdt * leverage) / current_price
            logger.info(f"📊 계산된 수량: {quantity:.6f} (금액: {amount_usdt} USDT, 레버리지: {leverage}x)")
            
            # 시장가 매수 주문
            order = exchange.create_market_buy_order(normalized_symbol, quantity)
            
            logger.info(f"🟢 롱 진입 성공: {symbol} | 수량: {quantity:.6f} | 가격: {current_price}")
            
            return {
                "success": True,
                "message": f"🟢 롱 진입 성공",
                "order": order,
                "signal": signal,
                "details": {
                    "symbol": symbol,
                    "side": "buy",
                    "quantity": quantity,
                    "price": current_price,
                    "leverage": leverage
                }
            }
        
        except Exception as e:
            logger.error(f"❌ 롱 진입 실패: {e}")
            return {
                "success": False,
                "message": f"❌ 롱 진입 실패: {str(e)}",
                "signal": signal
            }
    
    def _execute_short_entry(self, exchange: ccxt.Exchange, symbol: str, signal: Dict) -> Dict:
        """숏 진입"""
        try:
            # 기존 포지션 확인
            long_position = self._get_position(exchange, symbol, 'long')
            short_position = self._get_position(exchange, symbol, 'short')
            
            # 같은 방향 포지션이 있으면 차단
            if short_position:
                return {
                    "success": False,
                    "message": "⚠️ 이미 숏 포지션이 있습니다. 분할 청산(short_exit)을 사용하세요.",
                    "signal": signal
                }
            
            # 반대 포지션이 있으면 먼저 100% 청산
            if long_position:
                logger.info(f"🔄 롱 포지션 감지 → 100% 청산 후 숏 진입")
                close_result = self._execute_long_exit(exchange, symbol, {"percent": 100})
                if not close_result["success"]:
                    return {
                        "success": False,
                        "message": f"❌ 기존 롱 포지션 청산 실패: {close_result['message']}",
                        "signal": signal
                    }
                logger.info(f"✅ 롱 포지션 청산 완료 → 숏 진입 진행")
            
            leverage = signal.get("leverage", self.config["trading"]["default_leverage"])
            amount_usdt = signal.get("amount", 100)
            
            # 심볼 정규화
            normalized_symbol = self._normalize_symbol(exchange, symbol)
            logger.info(f"🔧 심볼 정규화: {symbol} -> {normalized_symbol}")
            
            # 레버리지 및 마진 모드 설정 (Binance Futures)
            if isinstance(exchange, ccxt.binance):
                try:
                    # 레버리지 설정
                    exchange.set_leverage(leverage, normalized_symbol)
                    logger.info(f"⚙️ 레버리지 설정: {leverage}x ({normalized_symbol})")
                    
                    # 마진 모드 설정 (isolated/cross)
                    margin_mode = self.config["trading"].get("margin_mode", "isolated")
                    exchange.set_margin_mode(margin_mode, normalized_symbol)
                    logger.info(f"⚙️ 마진 모드 설정: {margin_mode} ({normalized_symbol})")
                except Exception as e:
                    logger.warning(f"⚠️ 레버리지/마진 모드 설정 실패 (계속 진행): {e}")
            
            # 현재 가격 조회
            ticker = exchange.fetch_ticker(normalized_symbol)
            current_price = ticker['last']
            logger.info(f"💰 현재 가격: {normalized_symbol} = {current_price}")
            
            # 수량 계산
            quantity = (amount_usdt * leverage) / current_price
            logger.info(f"📊 계산된 수량: {quantity:.6f} (금액: {amount_usdt} USDT, 레버리지: {leverage}x)")
            
            # 시장가 매도 주문
            order = exchange.create_market_sell_order(normalized_symbol, quantity)
            
            logger.info(f"🔴 숏 진입 성공: {symbol} | 수량: {quantity:.6f} | 가격: {current_price}")
            
            return {
                "success": True,
                "message": f"🔴 숏 진입 성공",
                "order": order,
                "signal": signal,
                "details": {
                    "symbol": symbol,
                    "side": "sell",
                    "quantity": quantity,
                    "price": current_price,
                    "leverage": leverage
                }
            }
        
        except Exception as e:
            logger.error(f"❌ 숏 진입 실패: {e}")
            return {
                "success": False,
                "message": f"❌ 숏 진입 실패: {str(e)}",
                "signal": signal
            }
    
    def _execute_long_exit(self, exchange: ccxt.Exchange, symbol: str, signal: Dict) -> Dict:
        """롱 청산 (익절/손절)"""
        try:
            percent = signal.get("percent", 100)  # 기본 100% 청산
            
            # percent 값 검증 (0-100 범위)
            if percent <= 0 or percent > 100:
                return {
                    "success": False,
                    "message": f"⚠️ 청산 비율은 1-100% 사이여야 합니다. 입력값: {percent}%",
                    "signal": signal
                }
            
            # 현재 포지션 조회
            long_position = self._get_position(exchange, symbol, 'long')
            
            if not long_position:
                # 포지션이 없으면 경고만 로그하고 성공으로 처리 (트레이딩뷰와 실제 포지션 불일치 대응)
                logger.warning(f"⚠️ 청산할 롱 포지션이 없습니다 (이미 청산되었거나 존재하지 않음)")
                if isinstance(exchange, ccxt.binance):
                    self._finalize_trend_cycle_if_flat(exchange, symbol)
                return {
                    "success": True,
                    "message": "ℹ️ 청산할 롱 포지션이 없습니다 (이미 처리됨)",
                    "signal": signal,
                    "skip_notification": True  # 디스코드 알림 건너뛰기
                }
            
            # 청산 수량 계산
            position_size = long_position['contracts']
            close_quantity = position_size * (percent / 100)
            
            # 청산 수량 검증
            if close_quantity <= 0:
                return {
                    "success": False,
                    "message": f"⚠️ 계산된 청산 수량이 0 이하입니다. 포지션: {position_size}, 비율: {percent}%",
                    "signal": signal
                }
            
            if close_quantity > position_size:
                logger.warning(f"⚠️ 청산 수량({close_quantity})이 포지션 크기({position_size})보다 큽니다. 포지션 크기로 조정합니다.")
                close_quantity = position_size
            
            # 심볼 정규화
            normalized_symbol = self._normalize_symbol(exchange, symbol)
            logger.info(f"🔧 청산 심볼 정규화: {symbol} -> {normalized_symbol}")
            
            # 시장가 매도 주문 (포지션 청산)
            order = exchange.create_market_sell_order(normalized_symbol, close_quantity, {
                'reduceOnly': True
            })
            
            logger.info(f"🟢 롱 청산 성공: {symbol} | 수량: {close_quantity:.6f} / {position_size:.6f} ({percent}%)")
            
            return {
                "success": True,
                "message": f"🟢 롱 청산 성공 ({percent}%)",
                "order": order,
                "signal": signal,
                "details": {
                    "symbol": symbol,
                    "side": "sell",
                    "quantity": close_quantity,
                    "position_size": position_size,
                    "percent": percent,
                    "entry_price": long_position.get('entryPrice', 0),
                    "leverage": long_position.get('leverage') or signal.get('leverage') or 1,
                    "order": order
                }
            }
        
        except Exception as e:
            logger.error(f"❌ 롱 청산 실패: {e}")
            return {
                "success": False,
                "message": f"❌ 롱 청산 실패: {str(e)}",
                "signal": signal
            }
    
    def _execute_short_exit(self, exchange: ccxt.Exchange, symbol: str, signal: Dict) -> Dict:
        """숏 청산 (익절/손절)"""
        try:
            percent = signal.get("percent", 100)  # 기본 100% 청산
            
            # percent 값 검증 (0-100 범위)
            if percent <= 0 or percent > 100:
                return {
                    "success": False,
                    "message": f"⚠️ 청산 비율은 1-100% 사이여야 합니다. 입력값: {percent}%",
                    "signal": signal
                }
            
            # 현재 포지션 조회
            short_position = self._get_position(exchange, symbol, 'short')
            
            if not short_position:
                # 포지션이 없으면 경고만 로그하고 성공으로 처리 (트레이딩뷰와 실제 포지션 불일치 대응)
                logger.warning(f"⚠️ 청산할 숏 포지션이 없습니다 (이미 청산되었거나 존재하지 않음)")
                if isinstance(exchange, ccxt.binance):
                    self._finalize_trend_cycle_if_flat(exchange, symbol)
                return {
                    "success": True,
                    "message": "ℹ️ 청산할 숏 포지션이 없습니다 (이미 처리됨)",
                    "signal": signal,
                    "skip_notification": True  # 디스코드 알림 건너뛰기
                }
            
            # 청산 수량 계산
            position_size = short_position['contracts']
            close_quantity = position_size * (percent / 100)
            
            # 청산 수량 검증
            if close_quantity <= 0:
                return {
                    "success": False,
                    "message": f"⚠️ 계산된 청산 수량이 0 이하입니다. 포지션: {position_size}, 비율: {percent}%",
                    "signal": signal
                }
            
            if close_quantity > position_size:
                logger.warning(f"⚠️ 청산 수량({close_quantity})이 포지션 크기({position_size})보다 큽니다. 포지션 크기로 조정합니다.")
                close_quantity = position_size
            
            # 심볼 정규화
            normalized_symbol = self._normalize_symbol(exchange, symbol)
            logger.info(f"🔧 청산 심볼 정규화: {symbol} -> {normalized_symbol}")
            
            # 시장가 매수 주문 (포지션 청산)
            order = exchange.create_market_buy_order(normalized_symbol, close_quantity, {
                'reduceOnly': True
            })
            
            logger.info(f"🔴 숏 청산 성공: {symbol} | 수량: {close_quantity:.6f} / {position_size:.6f} ({percent}%)")
            
            return {
                "success": True,
                "message": f"🔴 숏 청산 성공 ({percent}%)",
                "order": order,
                "signal": signal,
                "details": {
                    "symbol": symbol,
                    "side": "buy",
                    "quantity": close_quantity,
                    "position_size": position_size,
                    "percent": percent,
                    "entry_price": short_position.get('entryPrice', 0),
                    "leverage": short_position.get('leverage') or signal.get('leverage') or 1,
                    "order": order
                }
            }
        
        except Exception as e:
            logger.error(f"❌ 숏 청산 실패: {e}")
            return {
                "success": False,
                "message": f"❌ 숏 청산 실패: {str(e)}",
                "signal": signal
            }

    def _setup_leverage_margin(self, exchange: ccxt.Exchange, normalized_symbol: str, leverage: int) -> None:
        """Binance 선물 레버리지·마진 모드 설정"""
        if not isinstance(exchange, ccxt.binance):
            return
        try:
            exchange.set_leverage(leverage, normalized_symbol)
            logger.info(f"⚙️ 레버리지 설정: {leverage}x ({normalized_symbol})")
            margin_mode = self.config["trading"].get("margin_mode", "isolated")
            exchange.set_margin_mode(margin_mode, normalized_symbol)
            logger.info(f"⚙️ 마진 모드 설정: {margin_mode} ({normalized_symbol})")
        except Exception as e:
            logger.warning(f"⚠️ 레버리지/마진 모드 설정 실패 (계속 진행): {e}")

    def _round_quantity(self, exchange: ccxt.Exchange, normalized_symbol: str, quantity: float) -> float:
        """거래소 수량 정밀도에 맞게 반올림"""
        try:
            markets = exchange.load_markets()
            market = markets.get(normalized_symbol)
            if market is None:
                for m in markets.values():
                    if m.get("id") == normalized_symbol:
                        market = m
                        break
            symbol_key = market["symbol"] if market else normalized_symbol
            return float(exchange.amount_to_precision(symbol_key, quantity))
        except Exception as e:
            logger.warning(f"⚠️ 수량 정밀도 조정 실패, 원본 사용: {e}")
            return quantity

    def _cancel_flip_ladder_orders(self, exchange: ccxt.Exchange, symbol: str) -> int:
        """플립 리밋·관련 스탑 등 미체결 주문 취소"""
        normalized_symbol = self._normalize_symbol(exchange, symbol)
        cancelled = 0
        try:
            open_orders = exchange.fetch_open_orders(normalized_symbol)
            for order in open_orders:
                order_type = str(order.get("type", "")).lower()
                is_entry_limit = order_type == "limit" and not order.get("reduceOnly", False)
                is_protective_stop = order_type in ("stop_market", "stop", "take_profit_market") and order.get("reduceOnly", False)
                if is_entry_limit or is_protective_stop:
                    exchange.cancel_order(order["id"], normalized_symbol)
                    cancelled += 1
                    logger.info(f"🗑️ 주문 취소: {normalized_symbol} id={order['id']} type={order_type}")
        except Exception as e:
            logger.warning(f"⚠️ 미체결 주문 취소 실패 ({normalized_symbol}): {e}")
        self._cancel_stop_sync_timers(normalized_symbol)
        self._flip_ladders.pop(normalized_symbol, None)
        return cancelled

    def _cancel_stop_sync_timers(self, normalized_symbol: str) -> None:
        """예약된 공통 손절 재시도 타이머 취소"""
        for timer in self._stop_sync_timers.pop(normalized_symbol, []):
            try:
                timer.cancel()
            except Exception:
                pass

    def _schedule_stop_sync_retries(self, exchange: ccxt.Exchange, normalized_symbol: str) -> None:
        """리밋은 웹훅 시점에 미체결 → 체결 후 포지션 생기면 손절을 맞추기 위해 지연 재시도"""
        self._cancel_stop_sync_timers(normalized_symbol)
        delays = (3, 8, 15, 30, 60, 90)
        timers = []
        for delay in delays:
            timer = threading.Timer(
                delay,
                self._stop_sync_retry_worker,
                args=(normalized_symbol, delay),
            )
            timer.daemon = True
            timer.start()
            timers.append(timer)
        self._stop_sync_timers[normalized_symbol] = timers
        logger.info(f"⏱️ 공통 손절 재시도 예약: {normalized_symbol} (최대 {len(delays)}회)")

    def _stop_sync_retry_worker(self, normalized_symbol: str, delay: float) -> None:
        try:
            ladder = self._flip_ladders.get(normalized_symbol)
            if not ladder or ladder.get("stop_synced"):
                return
            exchange = self.exchanges.get("binance")
            if not exchange:
                return
            logger.info(f"🔄 공통 손절 재시도 (+{int(delay)}s): {normalized_symbol}")
            self._try_sync_shared_stop(exchange, normalized_symbol)
        except Exception as e:
            logger.warning(f"⚠️ 공통 손절 재시도 오류 ({normalized_symbol}): {e}")

    def _has_open_stop_order(self, exchange: ccxt.Exchange, normalized_symbol: str) -> bool:
        try:
            for order in exchange.fetch_open_orders(normalized_symbol):
                order_type = str(order.get("type", "")).lower()
                if order_type in ("stop_market", "stop", "take_profit_market") and order.get("reduceOnly", False):
                    return True
        except Exception as e:
            logger.warning(f"⚠️ 스탑 주문 조회 실패 ({normalized_symbol}): {e}")
        return False

    def _cancel_stop_orders(self, exchange: ccxt.Exchange, normalized_symbol: str) -> None:
        """기존 reduceOnly 스탑 주문만 취소"""
        try:
            open_orders = exchange.fetch_open_orders(normalized_symbol)
            for order in open_orders:
                order_type = str(order.get("type", "")).lower()
                if order_type in ("stop_market", "stop", "take_profit_market") and order.get("reduceOnly", False):
                    exchange.cancel_order(order["id"], normalized_symbol)
                    logger.info(f"🗑️ 스탑 주문 취소: {normalized_symbol} id={order['id']}")
        except Exception as e:
            logger.warning(f"⚠️ 스탑 주문 취소 실패 ({normalized_symbol}): {e}")

    def _try_sync_shared_stop(self, exchange: ccxt.Exchange, normalized_symbol: str) -> None:
        """체결된 포지션에 공통 손절(STOP_MARKET closePosition) 동기화"""
        ladder = self._flip_ladders.get(normalized_symbol)
        if not ladder:
            return
        if ladder.get("stop_synced") and self._has_open_stop_order(exchange, normalized_symbol):
            return
        side = ladder.get("side")
        stop_loss = ladder.get("stop_loss")
        if not side or not stop_loss:
            return
        position = self._get_position(exchange, normalized_symbol, side)
        if not position or float(position.get("contracts") or 0) <= 0:
            logger.info(f"ℹ️ 포지션 없음 → 공통 손절 대기 ({normalized_symbol})")
            return
        try:
            self._cancel_stop_orders(exchange, normalized_symbol)
            close_side = "sell" if side == "long" else "buy"
            params = {
                "stopPrice": float(stop_loss),
                "closePosition": True,
                "workingType": "CONTRACT_PRICE",
            }
            order = exchange.create_order(
                normalized_symbol,
                "STOP_MARKET",
                close_side,
                None,
                None,
                params,
            )
            ladder["stop_synced"] = True
            ladder["stop_order_id"] = order.get("id")
            self._cancel_stop_sync_timers(normalized_symbol)
            logger.info(f"🛡️ 공통 손절 설정 완료: {normalized_symbol} {side} @ {stop_loss} (id={order.get('id')})")
        except Exception as e:
            logger.warning(f"⚠️ 공통 손절 설정 실패 ({normalized_symbol}): {e}")

    def _execute_limit_ladder(
        self,
        exchange: ccxt.Exchange,
        symbol: str,
        signal: Dict[str, Any],
        is_short: bool,
    ) -> Dict[str, Any]:
        """플립 리밋 일괄 접수 (long_limit_ladder / short_limit_ladder)"""
        action = "short_limit_ladder" if is_short else "long_limit_ladder"
        side_label = "숏" if is_short else "롱"
        try:
            if not isinstance(exchange, ccxt.binance):
                return {
                    "success": False,
                    "message": "❌ 리밋 주문은 Binance 선물만 지원합니다",
                    "signal": signal,
                }

            limits = signal.get("limits") or []
            if not limits:
                return {
                    "success": False,
                    "message": "❌ limits 배열이 비어 있습니다",
                    "signal": signal,
                }

            stop_loss = float(signal.get("stop_loss", 0))
            if stop_loss <= 0:
                return {
                    "success": False,
                    "message": "❌ stop_loss 필드가 필요합니다",
                    "signal": signal,
                }

            max_slot = int(
                self.config.get("trading", {}).get("max_flip_limit_slots", MAX_FLIP_LIMIT_SLOTS)
            )
            normalized_symbol = self._normalize_symbol(exchange, symbol)
            leverage = int(signal.get("leverage", self.config["trading"]["default_leverage"]))
            position_side = "short" if is_short else "long"
            order_side = "sell" if is_short else "buy"

            sorted_limits = sorted(limits, key=lambda x: int(x.get("slot", 0)))

            with self._get_symbol_lock(normalized_symbol):
                self._setup_leverage_margin(exchange, normalized_symbol, leverage)
                cancelled = self._cancel_flip_ladder_orders(exchange, symbol)
                logger.info(
                    f"🔄 플립 리밋 일괄 시작 ({normalized_symbol}) — 취소: {cancelled}건, "
                    f"접수 예정: {len(sorted_limits)}건"
                )
                self._flip_ladders[normalized_symbol] = {
                    "side": position_side,
                    "stop_loss": stop_loss,
                    "leverage": leverage,
                    "orders": [],
                    "stop_synced": False,
                }

                created: List[Dict[str, Any]] = []
                for lim in sorted_limits:
                    slot = int(lim.get("slot", 0))
                    price = float(lim.get("price", 0))
                    share_pct = float(lim.get("share_pct", 0))
                    if slot < 1 or slot > max_slot:
                        return {
                            "success": False,
                            "message": f"❌ slot은 1~{max_slot} 이어야 합니다. 입력값: {slot}",
                            "signal": signal,
                        }
                    if price <= 0 or share_pct <= 0:
                        return {
                            "success": False,
                            "message": f"❌ slot{slot} price/share_pct가 유효하지 않습니다",
                            "signal": signal,
                        }

                    amount_usdt = self._calc_limit_amount_usdt(exchange, signal, share_pct)
                    quantity = (amount_usdt * leverage) / price
                    quantity = self._round_quantity(exchange, normalized_symbol, quantity)
                    if quantity <= 0:
                        return {
                            "success": False,
                            "message": f"❌ slot{slot} 수량이 0 이하입니다",
                            "signal": signal,
                        }

                    order = exchange.create_order(
                        normalized_symbol,
                        "limit",
                        order_side,
                        quantity,
                        price,
                        {"timeInForce": "GTC"},
                    )
                    self._flip_ladders[normalized_symbol]["orders"].append({
                        "slot": slot,
                        "order_id": order.get("id"),
                        "quantity": quantity,
                        "price": price,
                    })
                    created.append({
                        "slot": slot,
                        "quantity": quantity,
                        "price": price,
                        "amount_usdt": amount_usdt,
                        "order_id": order.get("id"),
                    })
                    logger.info(
                        f"📌 {side_label} 리밋 slot{slot}: {normalized_symbol} "
                        f"qty={quantity} @ {price} ({share_pct}%)"
                    )

                self._schedule_stop_sync_retries(exchange, normalized_symbol)

            return {
                "success": True,
                "message": f"📌 {side_label} 리밋 {len(created)}건 일괄 접수",
                "signal": signal,
                "details": {
                    "action": action,
                    "symbol": symbol,
                    "side": order_side,
                    "stop_loss": stop_loss,
                    "leverage": leverage,
                    "orders": created,
                    "order_count": len(created),
                },
            }
        except Exception as e:
            logger.error(f"❌ {action} 실패: {e}")
            return {
                "success": False,
                "message": f"❌ {side_label} 리밋 일괄 실패: {str(e)}",
                "signal": signal,
            }

    def _execute_limit_entry(
        self,
        exchange: ccxt.Exchange,
        symbol: str,
        signal: Dict[str, Any],
        is_short: bool,
    ) -> Dict[str, Any]:
        """플립 리밋 진입 (long_limit / short_limit)"""
        action = "short_limit" if is_short else "long_limit"
        side_label = "숏" if is_short else "롱"
        try:
            if not isinstance(exchange, ccxt.binance):
                return {
                    "success": False,
                    "message": "❌ 리밋 주문은 Binance 선물만 지원합니다",
                    "signal": signal,
                }

            price = float(signal.get("price", 0))
            stop_loss = float(signal.get("stop_loss", 0))
            slot = int(signal.get("slot", 0))
            amount_usdt = float(signal.get("amount", 0))

            if price <= 0 or stop_loss <= 0:
                return {
                    "success": False,
                    "message": "❌ price, stop_loss 필드가 필요합니다",
                    "signal": signal,
                }
            max_slot = int(
                self.config.get("trading", {}).get("max_flip_limit_slots", MAX_FLIP_LIMIT_SLOTS)
            )
            if slot < 1 or slot > max_slot:
                return {
                    "success": False,
                    "message": f"❌ slot은 1~{max_slot} 이어야 합니다. 입력값: {slot}",
                    "signal": signal,
                }
            if amount_usdt <= 0:
                return {
                    "success": False,
                    "message": "❌ 주문 금액(amount)이 0 이하입니다",
                    "signal": signal,
                }

            normalized_symbol = self._normalize_symbol(exchange, symbol)
            leverage = int(signal.get("leverage", self.config["trading"]["default_leverage"]))
            position_side = "short" if is_short else "long"

            with self._get_symbol_lock(normalized_symbol):
                self._setup_leverage_margin(exchange, normalized_symbol, leverage)

                if slot == 1:
                    cancelled = self._cancel_flip_ladder_orders(exchange, symbol)
                    logger.info(f"🔄 새 플립 리밋 시작 ({normalized_symbol}) — 취소된 주문: {cancelled}건")
                    self._flip_ladders[normalized_symbol] = {
                        "side": position_side,
                        "stop_loss": stop_loss,
                        "leverage": leverage,
                        "orders": [],
                        "stop_synced": False,
                    }
                elif normalized_symbol not in self._flip_ladders:
                    logger.warning(f"⚠️ slot {slot} 수신 — slot 1 없음, 리밋 상태 새로 생성")
                    self._flip_ladders[normalized_symbol] = {
                        "side": position_side,
                        "stop_loss": stop_loss,
                        "leverage": leverage,
                        "orders": [],
                        "stop_synced": False,
                    }

                quantity = (amount_usdt * leverage) / price
                quantity = self._round_quantity(exchange, normalized_symbol, quantity)
                if quantity <= 0:
                    return {
                        "success": False,
                        "message": f"❌ 계산된 수량이 0 이하입니다 (amount={amount_usdt}, price={price})",
                        "signal": signal,
                    }

                order_side = "sell" if is_short else "buy"
                order = exchange.create_order(
                    normalized_symbol,
                    "limit",
                    order_side,
                    quantity,
                    price,
                    {"timeInForce": "GTC"},
                )

                ladder = self._flip_ladders[normalized_symbol]
                ladder["stop_loss"] = stop_loss
                ladder["orders"].append({
                    "slot": slot,
                    "order_id": order.get("id"),
                    "quantity": quantity,
                    "price": price,
                })

                self._schedule_stop_sync_retries(exchange, normalized_symbol)

            logger.info(
                f"📌 {side_label} 리밋 slot{slot}: {normalized_symbol} "
                f"qty={quantity} @ {price} SL={stop_loss}"
            )

            return {
                "success": True,
                "message": f"📌 {side_label} 리밋 slot{slot} 접수",
                "order": order,
                "signal": signal,
                "details": {
                    "action": action,
                    "symbol": symbol,
                    "slot": slot,
                    "side": order_side,
                    "quantity": quantity,
                    "price": price,
                    "stop_loss": stop_loss,
                    "leverage": leverage,
                    "amount_usdt": amount_usdt,
                },
            }
        except Exception as e:
            logger.error(f"❌ {action} 실패: {e}")
            return {
                "success": False,
                "message": f"❌ {side_label} 리밋 실패: {str(e)}",
                "signal": signal,
            }

    def _cancel_trend_cycle_orders(self, exchange: ccxt.Exchange, symbol: str) -> int:
        """정추세 사이클 관련 미체결(진입 리밋·TP·스탑) 취소"""
        normalized_symbol = self._normalize_symbol(exchange, symbol)
        cancelled = 0
        try:
            for order in exchange.fetch_open_orders(normalized_symbol):
                exchange.cancel_order(order["id"], normalized_symbol)
                cancelled += 1
        except Exception as e:
            logger.warning(f"⚠️ 정추세 주문 취소 실패 ({normalized_symbol}): {e}")
        self._cancel_trend_sync_timers(normalized_symbol)
        self._trend_cycles.pop(normalized_symbol, None)
        return cancelled

    def _trend_cycle_contracts(
        self, exchange: ccxt.Exchange, symbol: str, cycle: Dict[str, Any]
    ) -> float:
        side = cycle.get("side")
        if not side:
            return 0.0
        position = self._get_position(exchange, symbol, side)
        return float(position.get("contracts") or 0) if position else 0.0

    def _finalize_trend_cycle_if_flat(self, exchange: ccxt.Exchange, symbol: str) -> int:
        """
        정추세: 거래소 API로 포지션이 한 번 확인된 뒤 수량이 0이면
        (익절·손절·수동 청산) 진입2 리밋 등 미체결 주문을 모두 취소한다.
        """
        normalized_symbol = self._normalize_symbol(exchange, symbol)
        cycle = self._trend_cycles.get(normalized_symbol)
        if not cycle:
            return 0
        contracts = self._trend_cycle_contracts(exchange, symbol, cycle)
        if contracts > 0:
            cycle["position_confirmed"] = True
            return 0
        if not cycle.get("position_confirmed"):
            return 0
        cancelled = self._cancel_trend_cycle_orders(exchange, symbol)
        logger.info(
            f"🧹 정추세 포지션 종료 — 미체결 {cancelled}건 취소 ({normalized_symbol})"
        )
        return cancelled

    def _cancel_trend_sync_timers(self, normalized_symbol: str) -> None:
        for timer in self._trend_sync_timers.pop(normalized_symbol, []):
            try:
                timer.cancel()
            except Exception:
                pass

    def _schedule_trend_protective_sync(self, exchange: ccxt.Exchange, normalized_symbol: str) -> None:
        """포지션 생긴 뒤 SL·TP 재시도"""
        self._cancel_trend_sync_timers(normalized_symbol)
        delays = (2, 5, 10, 20, 40, 60)
        timers = []
        for delay in delays:
            timer = threading.Timer(
                delay,
                self._trend_protective_sync_worker,
                args=(normalized_symbol, delay),
            )
            timer.daemon = True
            timer.start()
            timers.append(timer)
        self._trend_sync_timers[normalized_symbol] = timers

    def _trend_protective_sync_worker(self, normalized_symbol: str, delay: float) -> None:
        try:
            cycle = self._trend_cycles.get(normalized_symbol)
            if not cycle:
                return
            exchange = self.exchanges.get("binance")
            if not exchange:
                return
            logger.info(f"🔄 정추세 SL/TP 동기화 (+{int(delay)}s): {normalized_symbol}")
            self._sync_trend_stop_loss(exchange, normalized_symbol, cycle)
            self._sync_trend_take_profits(exchange, normalized_symbol, cycle)
            self._finalize_trend_cycle_if_flat(exchange, normalized_symbol)
        except Exception as e:
            logger.warning(f"⚠️ 정추세 SL/TP 동기화 오류 ({normalized_symbol}): {e}")

    def _sync_trend_stop_loss(
        self, exchange: ccxt.Exchange, normalized_symbol: str, cycle: Dict[str, Any]
    ) -> None:
        if cycle.get("stop_synced") and self._has_open_stop_order(exchange, normalized_symbol):
            return
        side = cycle.get("side")
        stop_loss = cycle.get("stop_loss")
        if not side or not stop_loss:
            return
        contracts = self._trend_cycle_contracts(exchange, normalized_symbol, cycle)
        if contracts <= 0:
            return
        cycle["position_confirmed"] = True
        try:
            self._cancel_stop_orders(exchange, normalized_symbol)
            close_side = "sell" if side == "long" else "buy"
            exchange.create_order(
                normalized_symbol,
                "STOP_MARKET",
                close_side,
                None,
                None,
                {
                    "stopPrice": float(stop_loss),
                    "closePosition": True,
                    "workingType": "CONTRACT_PRICE",
                },
            )
            cycle["stop_synced"] = True
            logger.info(f"🛡️ 정추세 손절 설정: {normalized_symbol} @ {stop_loss}")
        except Exception as e:
            logger.warning(f"⚠️ 정추세 손절 설정 실패 ({normalized_symbol}): {e}")

    def _sync_trend_take_profits(
        self, exchange: ccxt.Exchange, normalized_symbol: str, cycle: Dict[str, Any]
    ) -> None:
        side = cycle.get("side")
        if not side:
            return
        contracts = self._trend_cycle_contracts(exchange, normalized_symbol, cycle)
        if contracts <= 0:
            return
        cycle["position_confirmed"] = True
        pos_size = contracts
        leverage = int(cycle.get("leverage") or 1)
        placed = cycle.setdefault("tp_placed_slots", set())
        close_side = "sell" if side == "long" else "buy"
        for tp in cycle.get("tps") or []:
            slot = int(tp.get("slot", 0))
            if slot in placed:
                continue
            price = float(tp.get("price", 0))
            share_pct = float(tp.get("share_pct", 0))
            if price <= 0 or share_pct <= 0:
                continue
            qty = pos_size * (share_pct / 100.0)
            qty = self._round_quantity(exchange, normalized_symbol, qty)
            if qty <= 0:
                continue
            try:
                exchange.create_order(
                    normalized_symbol,
                    "limit",
                    close_side,
                    qty,
                    price,
                    {"timeInForce": "GTC", "reduceOnly": True},
                )
                placed.add(slot)
                logger.info(
                    f"🎯 정추세 TP slot{slot}: {normalized_symbol} "
                    f"qty={qty} @ {price} ({share_pct}% of pos)"
                )
            except Exception as e:
                logger.warning(f"⚠️ 정추세 TP slot{slot} 실패 ({normalized_symbol}): {e}")

    def _execute_trend_flip_start(
        self, exchange: ccxt.Exchange, symbol: str, signal: Dict[str, Any]
    ) -> Dict[str, Any]:
        """정추세 플립: 매수1 시장 + 매수2 리밋(트레일) + SL + TP 예약"""
        is_short = bool(signal.get("is_short", False))
        side_label = "숏" if is_short else "롱"
        position_side = "short" if is_short else "long"
        try:
            if not isinstance(exchange, ccxt.binance):
                return {
                    "success": False,
                    "message": "❌ 정추세는 Binance 선물만 지원합니다",
                    "signal": signal,
                }
            stop_loss = float(signal.get("stop_loss", 0))
            if stop_loss <= 0:
                return {"success": False, "message": "❌ stop_loss 필드가 필요합니다", "signal": signal}

            buys = signal.get("buys") or []
            tps = signal.get("tps") or []
            normalized_symbol = self._normalize_symbol(exchange, symbol)
            leverage = int(signal.get("leverage", self.config["trading"]["default_leverage"]))

            results: List[Dict[str, Any]] = []
            with self._get_symbol_lock(normalized_symbol):
                self._setup_leverage_margin(exchange, normalized_symbol, leverage)
                cancelled = self._cancel_trend_cycle_orders(exchange, symbol)
                logger.info(f"🔄 정추세 플립 시작 ({normalized_symbol}) — 취소 {cancelled}건")

                self._trend_cycles[normalized_symbol] = {
                    "side": position_side,
                    "stop_loss": stop_loss,
                    "leverage": leverage,
                    "tps": tps,
                    "stop_synced": False,
                    "tp_placed_slots": set(),
                    "entry_orders": [],
                    "position_confirmed": False,
                }

                for buy in sorted(buys, key=lambda x: int(x.get("slot", 0))):
                    slot = int(buy.get("slot", 0))
                    kind = str(buy.get("kind", "")).lower()
                    share_pct = float(buy.get("share_pct", 0))
                    if share_pct <= 0:
                        continue
                    amount_usdt = self._calc_limit_amount_usdt(exchange, signal, share_pct)

                    if kind == "market":
                        entry_signal = {
                            **signal,
                            "amount": amount_usdt,
                            "leverage": leverage,
                            "add_to_position": True,
                        }
                        res = self._execute_trend_market_entry(
                            exchange, symbol, entry_signal, is_short=is_short
                        )
                        results.append({"slot": slot, "kind": "market", "result": res})
                    elif kind == "limit":
                        price = float(buy.get("price", 0))
                        if price <= 0:
                            continue
                        qty = (amount_usdt * leverage) / price
                        qty = self._round_quantity(exchange, normalized_symbol, qty)
                        if qty <= 0:
                            continue
                        order_side = "sell" if is_short else "buy"
                        order = exchange.create_order(
                            normalized_symbol,
                            "limit",
                            order_side,
                            qty,
                            price,
                            {"timeInForce": "GTC"},
                        )
                        self._trend_cycles[normalized_symbol]["entry_orders"].append(
                            {"slot": slot, "order_id": order.get("id"), "price": price}
                        )
                        results.append(
                            {
                                "slot": slot,
                                "kind": "limit",
                                "price": price,
                                "quantity": qty,
                                "order_id": order.get("id"),
                            }
                        )
                        logger.info(
                            f"📌 정추세 매수2 리밋 slot{slot}: {normalized_symbol} "
                            f"qty={qty} @ {price}"
                        )

                cycle_ref = self._trend_cycles[normalized_symbol]
                self._sync_trend_stop_loss(exchange, normalized_symbol, cycle_ref)
                self._sync_trend_take_profits(exchange, normalized_symbol, cycle_ref)
                self._schedule_trend_protective_sync(exchange, normalized_symbol)

                market_steps = [r for r in results if r.get("kind") == "market"]
                if market_steps and not any(
                    r.get("result", {}).get("success") for r in market_steps
                ):
                    self._cancel_trend_cycle_orders(exchange, symbol)
                    return {
                        "success": False,
                        "message": f"❌ 정추세 {side_label} 시장 진입(매수1) 실패",
                        "signal": signal,
                        "details": {"steps": results},
                    }

            return {
                "success": True,
                "message": f"📈 정추세 {side_label} 플립 시작 (매수1 시장 + 매수2 리밋)",
                "signal": signal,
                "details": {
                    "action": "trend_flip_start",
                    "symbol": symbol,
                    "is_short": is_short,
                    "stop_loss": stop_loss,
                    "leverage": leverage,
                    "steps": results,
                    "tp_count": len(tps),
                },
            }
        except Exception as e:
            logger.error(f"❌ trend_flip_start 실패: {e}")
            return {
                "success": False,
                "message": f"❌ 정추세 플립 실패: {str(e)}",
                "signal": signal,
            }

    def _execute_trend_market_entry(
        self,
        exchange: ccxt.Exchange,
        symbol: str,
        signal: Dict[str, Any],
        is_short: bool,
    ) -> Dict[str, Any]:
        """정추세 추가 시장 진입 (매수3~N) — 동일 방향 포지션에 추가"""
        side_label = "숏" if is_short else "롱"
        try:
            if "amount" not in signal and "share_pct" in signal:
                signal = dict(signal)
                signal["amount"] = self._calc_limit_amount_usdt(
                    exchange, signal, float(signal["share_pct"])
                )
            add = bool(signal.get("add_to_position", True))
            if is_short:
                if add:
                    return self._execute_short_entry_add(exchange, symbol, signal)
                return self._execute_short_entry(exchange, symbol, signal)
            if add:
                return self._execute_long_entry_add(exchange, symbol, signal)
            return self._execute_long_entry(exchange, symbol, signal)
        except Exception as e:
            logger.error(f"❌ trend_market_entry 실패: {e}")
            return {
                "success": False,
                "message": f"❌ 정추세 {side_label} 시장 추가 실패: {str(e)}",
                "signal": signal,
            }

    def _execute_long_entry_add(
        self, exchange: ccxt.Exchange, symbol: str, signal: Dict[str, Any]
    ) -> Dict[str, Any]:
        """롱 포지션 추가 (정추세 매수3~N)"""
        try:
            short_position = self._get_position(exchange, symbol, "short")
            if short_position:
                close_result = self._execute_short_exit(exchange, symbol, {"percent": 100})
                if not close_result["success"]:
                    return close_result
            leverage = int(signal.get("leverage", self.config["trading"]["default_leverage"]))
            amount_usdt = float(signal.get("amount", 0))
            normalized_symbol = self._normalize_symbol(exchange, symbol)
            self._setup_leverage_margin(exchange, normalized_symbol, leverage)
            ticker = exchange.fetch_ticker(normalized_symbol)
            current_price = ticker["last"]
            quantity = (amount_usdt * leverage) / current_price
            quantity = self._round_quantity(exchange, normalized_symbol, quantity)
            if quantity <= 0:
                return {"success": False, "message": "❌ 수량 0 이하", "signal": signal}
            order = exchange.create_market_buy_order(normalized_symbol, quantity)
            normalized = self._normalize_symbol(exchange, symbol)
            cycle = self._trend_cycles.get(normalized)
            if cycle:
                self._sync_trend_stop_loss(exchange, normalized, cycle)
                self._sync_trend_take_profits(exchange, normalized, cycle)
                self._schedule_trend_protective_sync(exchange, normalized)
            slot = signal.get("slot", "?")
            logger.info(f"🟢 정추세 롱 추가 매수{slot}: {quantity:.6f}")
            return {
                "success": True,
                "message": f"🟢 정추세 롱 추가 매수 (slot {slot})",
                "order": order,
                "signal": signal,
                "details": {
                    "symbol": symbol,
                    "quantity": quantity,
                    "price": current_price,
                    "slot": slot,
                },
            }
        except Exception as e:
            return {"success": False, "message": f"❌ 롱 추가 실패: {str(e)}", "signal": signal}

    def _execute_short_entry_add(
        self, exchange: ccxt.Exchange, symbol: str, signal: Dict[str, Any]
    ) -> Dict[str, Any]:
        """숏 포지션 추가 (정추세 매수3~N)"""
        try:
            long_position = self._get_position(exchange, symbol, "long")
            if long_position:
                close_result = self._execute_long_exit(exchange, symbol, {"percent": 100})
                if not close_result["success"]:
                    return close_result
            leverage = int(signal.get("leverage", self.config["trading"]["default_leverage"]))
            amount_usdt = float(signal.get("amount", 0))
            normalized_symbol = self._normalize_symbol(exchange, symbol)
            self._setup_leverage_margin(exchange, normalized_symbol, leverage)
            ticker = exchange.fetch_ticker(normalized_symbol)
            current_price = ticker["last"]
            quantity = (amount_usdt * leverage) / current_price
            quantity = self._round_quantity(exchange, normalized_symbol, quantity)
            if quantity <= 0:
                return {"success": False, "message": "❌ 수량 0 이하", "signal": signal}
            order = exchange.create_market_sell_order(normalized_symbol, quantity)
            normalized = self._normalize_symbol(exchange, symbol)
            cycle = self._trend_cycles.get(normalized)
            if cycle:
                self._sync_trend_stop_loss(exchange, normalized, cycle)
                self._sync_trend_take_profits(exchange, normalized, cycle)
                self._schedule_trend_protective_sync(exchange, normalized)
            slot = signal.get("slot", "?")
            logger.info(f"🔴 정추세 숏 추가 매수{slot}: {quantity:.6f}")
            return {
                "success": True,
                "message": f"🔴 정추세 숏 추가 매수 (slot {slot})",
                "order": order,
                "signal": signal,
                "details": {
                    "symbol": symbol,
                    "quantity": quantity,
                    "price": current_price,
                    "slot": slot,
                },
            }
        except Exception as e:
            return {"success": False, "message": f"❌ 숏 추가 실패: {str(e)}", "signal": signal}
    
    def get_balance(self, exchange_name: str = "binance") -> Optional[Dict]:
        """잔고 조회"""
        if exchange_name not in self.exchanges:
            return None
        
        try:
            exchange = self.exchanges[exchange_name]
            balance = exchange.fetch_balance()
            return balance
        except Exception as e:
            logger.error(f"❌ 잔고 조회 실패: {e}")
            return None
    
    def get_positions(self, exchange_name: str = "binance") -> Optional[list]:
        """포지션 조회"""
        if exchange_name not in self.exchanges:
            return None
        
        try:
            exchange = self.exchanges[exchange_name]
            positions = exchange.fetch_positions()
            # 포지션이 있는 것만 필터링
            return [p for p in positions if p['contracts'] > 0]
        except Exception as e:
            logger.error(f"❌ 포지션 조회 실패: {e}")
            return None


# 싱글톤 인스턴스
trading_engine = TradingEngine()


if __name__ == "__main__":
    # 테스트 코드
    print("🧪 TradingEngine 테스트")
    
    # 테스트 시그널
    test_signal = {
        "action": "long_entry",
        "symbol": "BTCUSDT",
        "exchange": "binance",
        "leverage": 10,
        "amount": 100
    }
    
    # 주의: 실제 거래가 실행되므로 테스트 시 주의!
    # result = trading_engine.execute_signal(test_signal)
    # print(f"실행 결과: {result}")
    
    print("⚠️  실제 거래 테스트는 주석을 해제하고 실행하세요")
