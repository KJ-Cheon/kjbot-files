"""
KJBot Discord Notifier
디스코드 웹훅을 통한 매매 알림 전송
"""

import requests
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


class DiscordNotifier:
    """디스코드 웹훅 알림 클래스"""
    
    def __init__(self, webhook_url: Optional[str] = None):
        self.webhook_url = webhook_url
        self.enabled = bool(webhook_url)
    
    def _get_kst_time(self) -> str:
        """한국 시간(KST, UTC+9) 반환"""
        utc_now = datetime.utcnow()
        kst_now = utc_now + timedelta(hours=9)
        return kst_now.strftime("%Y-%m-%d %H:%M:%S KST")
    
    def set_webhook_url(self, webhook_url: str):
        """웹훅 URL 설정"""
        self.webhook_url = webhook_url
        self.enabled = bool(webhook_url)
    
    def send_trade_notification(self, result: Dict[str, Any]) -> bool:
        """
        매매 알림 전송
        
        Args:
            result: trading_engine.execute_signal()의 반환값
        
        Returns:
            전송 성공 여부
        """
        if not self.enabled or not self.webhook_url:
            return False
        
        try:
            # 알림 메시지 생성
            message = self._format_trade_message(result)
            
            # 디스코드 웹훅 전송
            response = requests.post(
                self.webhook_url,
                json={"content": message},
                timeout=5
            )
            
            if response.status_code == 204:
                logger.info("✅ 디스코드 알림 전송 성공")
                return True
            else:
                logger.error(f"❌ 디스코드 알림 전송 실패: {response.status_code}")
                return False
        
        except Exception as e:
            logger.error(f"❌ 디스코드 알림 오류: {e}")
            return False
    
    def _format_trade_message(self, result: Dict[str, Any]) -> str:
        """매매 결과를 디스코드 메시지로 포맷팅"""
        success = result.get("success", False)
        message_text = result.get("message", "")
        signal = result.get("signal", {})
        details = result.get("details", {})
        
        # 액션 타입 확인
        action = signal.get("action", "unknown")
        
        # 타임스탬프 (한국 시간)
        timestamp = self._get_kst_time()
        
        # 실패한 경우
        if not success:
            return self._format_failure_message(action, signal, message_text, timestamp)
        
        # 성공한 경우 - 진입/청산 구분
        if "entry" in action:
            return self._format_entry_message(action, signal, details, timestamp)
        elif "exit" in action:
            return self._format_exit_message(action, signal, details, timestamp)
        else:
            return f"```\n⚠️ 알 수 없는 액션\n\n{message_text}\n⏰ {timestamp}\n```"
    
    def _format_entry_message(self, action: str, signal: Dict, details: Dict, timestamp: str) -> str:
        """진입 메시지 포맷팅"""
        is_long = "long" in action
        emoji = "🟢" if is_long else "🔴"
        direction = "롱" if is_long else "숏"
        
        symbol = details.get("symbol", signal.get("symbol", "N/A"))
        quantity = details.get("quantity", 0)
        price = details.get("price", 0)
        leverage = details.get("leverage", signal.get("leverage", 1))
        
        # 증거금 계산 (수량 * 가격 / 레버리지)
        margin = (quantity * price) / leverage if leverage > 0 else 0
        
        message = f"```\n{emoji} {direction} 진입 성공\n\n"
        message += "━━━━━━━━━━━━━━━━━━━━\n"
        message += f"📊 심볼: {symbol}\n"
        message += f"💰 수량: {quantity:.6f}\n"
        message += f"💵 진입가: ${price:,.2f}\n"
        message += f"⚡ 레버리지: {leverage}x\n"
        message += f"💸 증거금: {margin:.2f} USDT\n"
        message += "━━━━━━━━━━━━━━━━━━━━\n"
        message += f"⏰ {timestamp}\n"
        message += "```"
        
        return message
    
    def _format_exit_message(self, action: str, signal: Dict, details: Dict, timestamp: str) -> str:
        """청산 메시지 포맷팅 (수익/손실 계산 포함)"""
        is_long = "long" in action
        emoji = "🟢" if is_long else "🔴"
        direction = "롱" if is_long else "숏"
        
        symbol = details.get("symbol", signal.get("symbol", "N/A"))
        quantity = details.get("quantity", 0)
        position_size = details.get("position_size", quantity)
        percent = details.get("percent", 100)
        
        # 주문 정보에서 가격 추출
        order = details.get("order")
        exit_price = 0
        entry_price = 0
        
        if order:
            exit_price = order.get("average", order.get("price", 0))
        
        # 진입가는 포지션 정보에서 가져와야 하지만, 현재는 details에 없음
        # 임시로 signal에서 가져오거나 0으로 설정
        entry_price = details.get("entry_price", 0)
        
        # 수익/손실 계산
        pnl_info = self._calculate_pnl(
            is_long=is_long,
            entry_price=entry_price,
            exit_price=exit_price,
            quantity=quantity,
            leverage=details.get("leverage", signal.get("leverage", 1))
        )
        
        message = f"```\n{emoji} {direction} 청산 ({percent}%)\n\n"
        message += "━━━━━━━━━━━━━━━━━━━━\n"
        message += f"📊 심볼: {symbol}\n"
        message += f"💰 청산 수량: {quantity:.6f} ({percent}%)\n"
        
        if entry_price > 0:
            message += f"📈 진입가: ${entry_price:,.2f}\n"
        if exit_price > 0:
            message += f"📉 청산가: ${exit_price:,.2f}\n"
        
        message += f"📊 전체 포지션: {position_size:.6f}\n"
        
        # 수익/손실 정보 추가
        if pnl_info and entry_price > 0 and exit_price > 0:
            pnl = pnl_info["net_pnl"]
            pnl_percent = pnl_info["pnl_percent"]
            pnl_emoji = "✅" if pnl >= 0 else "❌"
            pnl_sign = "+" if pnl >= 0 else ""
            
            message += "\n💵 손익 계산:\n"
            message += f"  • 총 손익: {pnl_sign}${pnl_info['gross_pnl']:.2f}\n"
            message += f"  • 진입 수수료: -${pnl_info['entry_fee']:.2f} (0.04%)\n"
            message += f"  • 청산 수수료: -${pnl_info['exit_fee']:.2f} (0.04%)\n"
            message += f"  • 순수익: {pnl_sign}${pnl:.2f} {pnl_emoji}\n"
            message += f"  • 수익률: {pnl_sign}{pnl_percent:.2f}%\n"
        
        message += "━━━━━━━━━━━━━━━━━━━━\n"
        message += f"⏰ {timestamp}\n"
        message += "```"
        
        return message
    
    def _calculate_pnl(self, is_long: bool, entry_price: float, exit_price: float, 
                       quantity: float, leverage: int) -> Optional[Dict[str, float]]:
        """
        수익/손실 계산 (바이낸스 선물 수수료 포함)
        
        Args:
            is_long: 롱 포지션 여부
            entry_price: 진입가
            exit_price: 청산가
            quantity: 수량
            leverage: 레버리지
        
        Returns:
            {
                "gross_pnl": 총 손익,
                "entry_fee": 진입 수수료,
                "exit_fee": 청산 수수료,
                "net_pnl": 순손익,
                "pnl_percent": 수익률(%)
            }
        """
        if entry_price <= 0 or exit_price <= 0 or quantity <= 0:
            return None
        
        # 포지션 가치
        entry_value = entry_price * quantity
        exit_value = exit_price * quantity
        
        # 총 손익 (레버리지 적용)
        if is_long:
            gross_pnl = (exit_price - entry_price) * quantity
        else:
            gross_pnl = (entry_price - exit_price) * quantity
        
        # 바이낸스 선물 수수료 (Taker: 0.04%)
        TAKER_FEE_RATE = 0.0004
        entry_fee = entry_value * TAKER_FEE_RATE
        exit_fee = exit_value * TAKER_FEE_RATE
        
        # 순손익
        net_pnl = gross_pnl - entry_fee - exit_fee
        
        # 증거금 (진입 금액 / 레버리지)
        margin = entry_value / leverage if leverage > 0 else entry_value
        
        # 수익률 (순손익 / 증거금 * 100)
        pnl_percent = (net_pnl / margin * 100) if margin > 0 else 0
        
        return {
            "gross_pnl": gross_pnl,
            "entry_fee": entry_fee,
            "exit_fee": exit_fee,
            "net_pnl": net_pnl,
            "pnl_percent": pnl_percent
        }
    
    def _format_failure_message(self, action: str, signal: Dict, message_text: str, timestamp: str) -> str:
        """실패 메시지 포맷팅"""
        symbol = signal.get("symbol", "N/A")
        
        # 액션 한글화
        action_kr = {
            "long_entry": "롱 진입",
            "short_entry": "숏 진입",
            "long_exit": "롱 청산",
            "short_exit": "숏 청산"
        }.get(action, action)
        
        message = f"```\n❌ {action_kr} 실패\n\n"
        message += "━━━━━━━━━━━━━━━━━━━━\n"
        message += f"📊 심볼: {symbol}\n"
        message += f"⚠️ 오류: {message_text}\n"
        message += "━━━━━━━━━━━━━━━━━━━━\n"
        message += f"⏰ {timestamp}\n"
        message += "```"
        
        return message
    
    def send_test_notification(self) -> bool:
        """테스트 알림 전송"""
        if not self.enabled or not self.webhook_url:
            return False
        
        try:
            timestamp = self._get_kst_time()
            message = f"```\n✅ 디스코드 알림 테스트\n\n"
            message += "━━━━━━━━━━━━━━━━━━━━\n"
            message += "🤖 KJBot 알림이 정상적으로\n"
            message += "    작동하고 있습니다!\n"
            message += "━━━━━━━━━━━━━━━━━━━━\n"
            message += f"⏰ {timestamp}\n"
            message += "```"
            
            response = requests.post(
                self.webhook_url,
                json={"content": message},
                timeout=5
            )
            
            return response.status_code == 204
        
        except Exception as e:
            logger.error(f"❌ 테스트 알림 전송 실패: {e}")
            return False


# 싱글톤 인스턴스
discord_notifier = DiscordNotifier()
